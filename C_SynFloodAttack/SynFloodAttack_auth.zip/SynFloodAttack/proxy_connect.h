#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <memory.h>
#include <errno.h>
#include <assert.h>
#include <sys/types.h>
#include <stdarg.h>
#include <fcntl.h>
#include <signal.h>

struct proxy_info
{
	char ip_addr[20];
	unsigned short port;
    char user_name[50];
    char password[50];
};

#define SOCKET int
#ifndef SOCKET_ERROR
#define SOCKET_ERROR -1
#endif

int local_resolve (const char *host, struct sockaddr_in *addr);
int open_connect(const char* host, unsigned short port);
int atomic_out( SOCKET s, char *buf, int size );
int atomic_in( SOCKET s, char *buf, int size );
int connect_via_socks5( SOCKET s , char* dest_host, unsigned short dest_port);
int connect_socks5_proxy(struct proxy_info* info, char* dest_host, unsigned short dest_port);