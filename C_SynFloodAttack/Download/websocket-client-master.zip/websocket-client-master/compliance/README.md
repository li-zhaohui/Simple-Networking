# Autobahn Testsuite

General information and installation instructions are available at http://autobahn.ws/testsuite .

## Running the test suite


  $ wstest -m fuzzingserver
  $ python test_fuzzingclient.py


