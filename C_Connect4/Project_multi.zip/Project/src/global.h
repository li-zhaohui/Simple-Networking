#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <memory.h>
#include <errno.h>
#include <unistd.h>
#include <ctype.h>
#include <assert.h>
#include <sys/types.h>
#include <stdarg.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#ifdef _WIN32
#include <windows.h>
#include <winsock.h>
#include <sys/stat.h>
#include <io.h>
#include <conio.h>
#define socket_errno() WSAGetLastError()
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define SOCKET int
#define closesocket close
#define socket_errno() (errno)
#endif
/* socket related definitions */
#ifndef SOCKET_ERROR
#define SOCKET_ERROR -1
#endif

enum {PLAYER_TURN =0x01, CPU_TURN = 0x02};
enum { ROWS = 7, COLS = 7 };
enum {BUF_LENGTH = 10};

// receive command from socket
int recvCommand(SOCKET s)
{
	char buffer[BUF_LENGTH];
	ssize_t got = recv(s, buffer, BUF_LENGTH, 0); // Options, not needed
	if(got >= 0)
	{
		int cmd;
		cmd = *((int*)buffer);
		return cmd;
	}
	return -1;
}

//send command to socket
void sendCommand(SOCKET s, int cmd)
{
	char buffer[BUF_LENGTH];
	*(int*)buffer = cmd;
	ssize_t sent = send(s, buffer, BUF_LENGTH,	0);
	if (sent <= 0)
	{
		printf("Sending data error \n");
	}
}

char get_char(int const grid_value)
{
	switch (grid_value)
	{
	case 0:
		return 'O';

	case 1:
		return 'X';

	case 2:
		return '#';

	default:
		return '?';
	}
}
void showResult(int won){
	
	// Notify the player who won.
	if (won == PLAYER_TURN)
	{
		printf("Player won!\n");
	}
	if (won == CPU_TURN)
	{
		printf("The CPU won!\n");
	}
}

// Prototypes
void drawGrid(char grid[][COLS])
{
// Draw the 'grid'
	for (int down = 0; down < ROWS; down++)
	{
		for (int across = 0; across < COLS; across++)
		{
			// If the value at this position in the array is 0, display _
			// otherwise display X
			printf("%c", get_char(grid[down][across]));
		}
		printf("\n");	//For next row
	}
}

void placePiece(char grid[][COLS], int col, int player_no)
{
	int j;
	for (j = 6; j >= 0; j--) //Looking up the height of the column for the first empty slot
	{
		if (grid[j][col] == 0)
		{
			break;
		}
	}
	grid[j][col] = player_no;
}

int playerTurn(char grid[][COLS])
{
	int j, column;
	printf("\nSelect a column (0 - 6) : ");
	scanf("%d", &column);
	if(column == -1)
		return -1;
	while (column < 0 || column > 6 || grid[0][column] != 0)
	{
		if(column < 0 || column > 6)
		{
			printf("\nIncorrect Selection (0-6): \n");
		}
		else
		{
			printf("The column is full, please enter another: \n");
		}
		scanf("%d", &column);
	}

	placePiece(grid, column, PLAYER_TURN);
	return column;
}

int computerTurn(char grid[][COLS])
{
	srand((unsigned int)time(NULL));
	while(1)
	{
		int randColumn = (rand() % COLS);
		if(grid[0][randColumn] == 0)
		{
			printf("CPU selected column %d\n", randColumn);
			placePiece(grid, randColumn, CPU_TURN);
			return randColumn;
		}
	}
	return -1;
}
int checkForWin(char grid[][COLS])
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i + 1][j] && grid[i][j] == grid[i + 2][j] && grid[i][j] == grid[i + 3][j])
			{
				return grid[i][j];
			}
		}
	}
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i][j + 1] && grid[i][j] == grid[i][j + 2] && grid[i][j] == grid[i][j + 3])
			{
				return grid[i][j];
			}
		}
	}
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i + 1][j + 1] && grid[i][j] == grid[i + 2][j + 2] && grid[i][j] == grid[i + 3][j + 3])
			{
				return grid[i][j];
			}
		}
	}
	for (int i = 0; i < 4; i++)
	{
		for (int j = 3; j < 7; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i + 1][j - 1] && grid[i][j] == grid[i + 2][j - 2] && grid[i][j] == grid[i + 3][j - 3])
			{
				return grid[i][j];
			}
		}
	}
	return 0;
}


int vertical(char grid[][COLS])
{
	for (int i = 1; i < 5; i++)
	{
		for (int j = 0; j < 7; j++)
		{	// If there are 3 markers vertically placed by the player, then block it by inserting a computer marker above it.
			if (grid[i][j] != 0 && grid[i][j] == grid[i + 1][j] && grid[i][j] == grid[i + 2][j] && grid[i - 1][j] == 0)
			{
				if (grid[i][j] == 2)
				{
					grid[i - 1][j] = 2;
					return j;
				}
				if (grid[i][j] == 1)
				{
					grid[i - 1][j] = 2;
					return j;
				}
			}
		}
	}
	return -1;
}

int horizontalLeft(char grid[][COLS])
{
	for (int i = 0; i < 7; i++)
	{
		for (int j = 1; j < 5; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i][j + 1] && grid[i][j] == grid[i][j + 2] && grid[i][j - 1] == 0)
			{
				if (grid[i][j] == 2)
				{
					if (i == 6)
					{
						grid[i][j - 1] = 2;
						return j - 1;
					}
					if (grid[i + 1][j - 1] != 0)
					{
						grid[i][j - 1] = 2;
						return j - 1;
					}
				}
				if (grid[i][j] == 1)
				{
					if (i == 6)
					{
						grid[i][j - 1] = 2;
						return j - 1;
					}
					if (grid[i + 1][j - 1] != 0)
					{
						grid[i][j - 1] = 2;
						return j - 1;
					}
				}
			}
		}
	}
	return -1;
}
int horizontalRight(char grid[][COLS])
{
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i][j + 1] && grid[i][j] == grid[i][j + 2] && grid[i][j + 3] == 0)
			{
				if (grid[i][j] == 2)
				{
					if (i == 6)
					{
						grid[6][j + 3] = 2;
						return j + 3;
					}
					if (grid[i + 1][j + 3] != 0)
					{
						grid[i][j + 3] = 2;
						return j + 3;
					}
				}
				if (grid[i][j] == 1)
				{
					if (i == 6)
					{
						grid[6][j + 3] = 2;
						return j + 3;
					}
					if (grid[i + 1][j + 3] != 0)
					{
						grid[i][j + 3] = 2;
						return j + 3;
					}
				}
			}
		}
	}
	return -1;
}
int horizontalMid(char grid[][COLS])
{
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i][j + 1] && grid[i][j] == grid[i][j + 3] && grid[i][j + 2] == 0)
			{
				if (grid[i][j] == 2)
				{
					if (i == 6)
					{
						grid[6][j + 2] = 2;
						return j + 2;
					}
					if (grid[i + 1][j + 2] != 0)
					{
						grid[i][j + 2] = 2;
						return j + 2;
					}
				}
				if (grid[i][j] == 1)
				{
					if (i == 6)
					{
						grid[6][j + 2] = 2;
						return j + 2;
					}
					if (grid[i + 1][j + 2] != 0)
					{
						grid[i][j + 2] = 2;
						return j + 2;
					}
				}
			}
			if (grid[i][j] != 0 && grid[i][j] == grid[i][j + 2] && grid[i][j] == grid[i][j + 3] && grid[i][j + 1] == 0)
			{
				if (grid[i][j] == 2)
				{
					if (i == 6)
					{
						grid[6][j + 1] = 2;
						return j + 1;
					}
					if (grid[i + 1][j + 1] != 0)
					{
						grid[6][j + 1] = 2;
						return j + 1;
					}
				}
				if (grid[i][j] == 1)
				{
					if (i == 6)
					{
						grid[6][j + 1] = 2;
						return j + 1;
					}
					if (grid[i + 1][j + 1] != 0)
					{
						grid[i][j + 1] = 2;
						return j + 1;
					}
				}
			}
		}
	}
	return -1;
}


int diagonalLeft(char grid[][COLS])
{
	for (int i = 1; i < 5; i++)
	{
		for (int j = 1; j < 5; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i + 1][j + 1] && grid[i][j] == grid[i + 2][j + 2] && grid[i - 1][j - 1] == 0 && grid[i][j - 1] != 0)
			{
				/* Top Left Diagonal. (\ )
									  (	\) */
				if (grid[i][j] == 2)
				{
					grid[i - 1][j - 1] = 2;
					return j - 1;
				}
				if (grid[i][j] == 1)
				{
					grid[i - 1][j - 1] = 2;
					return j - 1;
				}
			}
		}
	}
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i + 1][j + 1] && grid[i][j] == grid[i + 2][j + 2] && grid[i + 3][j + 3] == 0)
			{
				if (grid[i][j] == 2)
				{
					if (i == 3)
					{
						grid[6][j + 3] = 2;
						return 1;
					}
					if (grid[i + 4][j + 3] != 0)
					{
						grid[i + 3][j + 3] = 2;
						return j + 3;
					}
				}
				if (grid[i][j] == 1)
				{
					if (i == 3)
					{
						grid[6][j + 3] = 2;
						return j + 3;
					}
					if (grid[i + 4][j + 3] != 0)
					{
						grid[i + 3][j + 3] = 2;
						return j + 3;
					}
				}
				// Bottom Right Diagonal.
			}
		}
	}
	return -1;
}

int diagonalRight(char grid[][COLS])
{
	for (int i = 1; i < 5; i++)
	{
		for (int j = 2; j < 5; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i + 1][j - 1] && grid[i][j] == grid[i + 2][j - 2] && grid[i - 1][j + 1] == 0 && grid[i][j + 1] != 0)
			{
				if (grid[i][j] == 2)
				{
					grid[i - 1][j + 1] = 2;
					return j + 1;
				}
				if (grid[i][j] == 1)
				{
					grid[i - 1][j + 1] = 2;
					return j + 1;
				}
				/* Top Right Diagonal. ( /)
									   (/ ) */
			}
		}
	}

	for (int i = 0; i < 4; i++)
	{
		for (int j = 3; j < 7; j++)
		{
			if (grid[i][j] != 0 && grid[i][j] == grid[i + 1][j - 1] && grid[i][j] == grid[i + 2][j - 2] && grid[i + 3][j - 3] == 0 && grid[i + 3][j - 3] != 2)
			{
				if (grid[i][j] == 2)
				{
					if (i == 3)
					{
						grid[6][j - 3] = 2;
						return j - 3;
					}
					if (grid[i + 2][j - 3] != 0)
					{
						grid[i + 3][j - 3] = 2;
						return j - 3;
					}
				}
				if (grid[i][j] == 1)
				{
					if (i == 3)
					{
						grid[6][j - 3] = 2;
						return j - 3;
					}
					if (grid[i + 2][j - 3] != 0)
					{
						grid[i + 3][j - 3] = 2;
						return j - 3;
					}
				}
			}
		}
	}
	return -1;
}

int checkMove(char grid[][COLS])
{
	int col = horizontalLeft(grid);
	if(col < 0) col = horizontalRight(grid);
	if(col < 0) col = horizontalMid(grid);
	if(col < 0) col = vertical(grid);
	if(col < 0) col = diagonalLeft(grid);
	if(col < 0) col = diagonalRight(grid);

	return col;
}
