#include "global.h"
SOCKET clientSocket;
void playGame();

int main()
{
#ifdef _WIN32
    WSADATA wsadata;
    WSAStartup( 0x101, &wsadata);
#endif /* _WIN32 */

    const uint16_t PORT = 50001;
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    // Port number in network byte order
    serverAddress.sin_port = htons(PORT);
    // Fill in the address of the server we wish to connect to
    const char * serverIP = "127.0.0.1";
    serverAddress.sin_addr.s_addr = inet_addr(serverIP);
    // Zero out the padding
    memset(serverAddress.sin_zero, 0, sizeof(serverAddress.sin_zero));

    // Attempt to connect
    int res = connect(clientSocket,
                      (struct sockaddr *)&serverAddress,
                      sizeof(serverAddress));
    if (res == 0)
    {
        printf("Connected to server OK \n");
        playGame();
        // That's all we want to do for now
        close(clientSocket);
    }
    else
    {
        printf("Could not connect, error from errno was %d\n", errno);
    }


    return 0;
}
void playGame()
{
    char grid[ROWS][COLS];
    memset(grid, 0, sizeof(grid));

    int coinToss = recvCommand(clientSocket);
    int col;
    if(coinToss == CPU_TURN)
    {
        col = recvCommand(clientSocket);
        printf("CPU is first turn\n");
        placePiece(grid, col, CPU_TURN);
    }
    else
    {
        printf("You are first turn\n");
    }
    // Draw the Connect 4 Grid
    drawGrid(grid);
    int won;
    do
    {
        col = playerTurn(grid);
        drawGrid(grid);
        sendCommand(clientSocket, col);
        // If the win has been found
        if((won = checkForWin(grid)))
        {
            break;
        }
        //receive column number
        col = recvCommand(clientSocket);
        printf("CPU selected %d\n", col);
        placePiece(grid, col, CPU_TURN);

        drawGrid(grid);
        // If the win has been found
        if((won = checkForWin(grid)))
        {
            break;
        }

    } while(true);
    showResult(won);
}