#include "global.h"
#include <pthread.h>
#include <termios.h>

void * dealWithClient(void * lpSocket);
void * acceptClient(void * lpSocket);

SOCKET serverSocket;

int main()
{
#ifdef _WIN32
    WSADATA wsadata;
    WSAStartup( 0x101, &wsadata);
#endif /* _WIN32 */

    const uint16_t PORT = 50001;

    // Create the socket using IPv4, TCP
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    // Set up the address
    struct sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    // Set the port number, but need to use network byte order
    serverAddress.sin_port = htons(PORT);
    // Set the IP address, localhost in dotted number format
    serverAddress.sin_addr.s_addr = inet_addr("127.0.0.1");
    // Slightly confusing, have to pad the rest of the structure with 0
    memset(serverAddress.sin_zero, 0, sizeof(serverAddress.sin_zero));
    // Bind this address. Have to cast to the general address structure
    // that the function is typed to accept
    int res = bind(serverSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress));

    if (res == 0)
    {
        printf("Bound...\n");
        // Tell the socket to start listening
        res = listen(serverSocket, 5);
        if(res == 0)
        {
            printf("Listening...\n");

            pthread_t accept_thread;
            pthread_create(&accept_thread, 0, acceptClient, &serverSocket);
            
            printf("Press a key to exit...");
            getchar();
        }
        else
        {
            printf("Could not listen, error was %d\n", res);
        }
    }
    else
    {
        printf("Could not bind, error was %d\n", res);
    }
    close(serverSocket);
}

void * acceptClient(void * lpSocket)
{
    SOCKET serverSocket = *(SOCKET*)lpSocket;
    do
    {

        // The following will probably use a separate thread to
        // do this for each client
        // Call accept to wait for a client to connect. This will
        // give us another socket
        SOCKET client_sock;
        // A structure for the client's address
        struct sockaddr_in clientAddress;
        size_t clientAddressSize = sizeof(clientAddress);
        client_sock = accept(serverSocket, 
                            (struct sockaddr *)&clientAddress,
                            (int*)&clientAddressSize);

        if(client_sock >= 0)
        {
            pthread_t tForClient;
            pthread_create(&tForClient, 0, dealWithClient, &client_sock);
        }
        else
        {
            printf("Could not accept, error was %d\n", client_sock);
        }
        /* code */
    } while (1);
}

// The code which deals with clients is in a separate function

void * dealWithClient(void* lpSocket)
{
    SOCKET client_sock = *(SOCKET*)lpSocket;
    if(client_sock >= 0)
    {
        printf("Client has connected\n");

        char grid[ROWS][COLS];
        memset(grid, 0, sizeof(grid));

        // Random coin toss to decide who goes first... CPU or player.
        srand((unsigned int)time(NULL));
        int coinToss = (rand() % 2) + 1;

        sendCommand(client_sock, coinToss);

        // If the coin toss was 2 then it is the players turn first.
        if (coinToss == CPU_TURN)
        {
            printf("CPU is first turn\n");
            int col = computerTurn(grid);
            sendCommand(client_sock, col);
        }
        else
        {
            printf("Player is first turn\n");
        }
        // Draw the Connect 4 Grid
        drawGrid(grid);
        
        int won = 0;
        int check = 0;      
        
        do
        {
            int col = recvCommand(client_sock);
            // Wait for the client to send us something
            if (col < 0)
            {
                printf("The game quited by player\n");
                break;
            }
            
            printf("Player selected column %d\n", col);
            placePiece(grid, col, PLAYER_TURN);
            // Refresh grid
            drawGrid(grid);

            // Check if a win has been found
            if((won = checkForWin(grid)))
            {
                break;
            }

            col = checkMove(grid);
            if(col < 0)
            {
                col = computerTurn(grid);
            }
            else
            {
                printf("CPU selected column %d\n", col);
            }

            sendCommand(client_sock, col);
            drawGrid(grid);
            // If the win has been found
            if((won = checkForWin(grid)))
            {
                break;
            }
            
        } while(won == 0);

        showResult(won);
        printf("\n");
        // Finished with this client
        close(client_sock);
    }
}
